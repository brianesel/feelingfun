# CSS Waving stick man

A Pen created on CodePen.io. Original URL: [https://codepen.io/brianesel/pen/ZEmrZgy](https://codepen.io/brianesel/pen/ZEmrZgy).

CSS Waving stick man